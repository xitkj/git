# Dark-FB no lisensi
Created By Sigit Mzhd
# Need Install
```
pkg install git
pkg install python2
pip2 install requests
pip2 install mechanize
```
Cyber XD
